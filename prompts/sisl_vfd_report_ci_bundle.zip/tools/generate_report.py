#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate "SISL_VFD_PA_2024 vs 2025_v01" (CSV + Excel) from repo CSVs.

Rules:
- Columns in outputs (order): Capacity (kW), Year, Model, Price (BDT)
- Capacity sort ascending (0.4 → ... → 400)
- Exactly 2 rows per group: 2024 first, 2025 second
- Group order within each capacity follows the 2024 list's sequence,
  then append any 2025-only models for that capacity
- If a capacity exists only in 2025, include it after all 2024 capacities (still sorted)
- Keep 2025 Model names verbatim from the 2025 source
- Excel banding: strict two-tone by group (White / Grey #B3B3B3 / White / Grey ...)
- Header bold, light grey; widths A=14, B=8, C=60, D=18; freeze at A2

Usage (auto-detect):
  python tools/generate_report.py

Usage (explicit):
  python tools/generate_report.py --y2024 data/your_2024.csv --y2025 data/your_2025.csv \
    --outprefix "reports/SISL_VFD_PA_2024 vs 2025_v01"

Environment variables (optional):
  Y2024_CSV, Y2025_CSV, OUTPREFIX
"""
import argparse, os, re, sys
from pathlib import Path
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side

DEFAULT_OUTPREFIX = "reports/SISL_VFD_PA_2024 vs 2025_v01"

CAP_GUESS = ["Capacity (KW)", "Capacity (kW)", "Capacity", "kW"]
MODEL_GUESS = ["Model (Rated Current)", "Model", "MODEL"]
PRICE_GUESS = ["Price (BDT)", "LP (BDT)", "List Price", "LP_BDT", "Price"]

def pick_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None

def read_price_csv(path):
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    cap_col = pick_col(df, CAP_GUESS)
    model_col = pick_col(df, MODEL_GUESS)
    price_col = pick_col(df, PRICE_GUESS)
    if not cap_col or not model_col or not price_col:
        raise RuntimeError(f"{path}: missing required columns. Need capacity/model/price. Got: {df.columns.tolist()}")
    # Parse capacity numeric (strip trailing 'K' if present)
    def parse_kw(s: str):
        s = str(s).strip()
        if s.endswith('K'):
            s = s[:-1]
        return float(s)
    out = pd.DataFrame({
        "Capacity (kW)": df[cap_col].map(parse_kw),
        "Model": df[model_col],              # keep verbatim text
        "Price (BDT)": df[price_col],        # keep as text
    })
    # Series letter for pairing (D/E/F/A). Treat CS with D; HEL stays HEL.
    def series_of(model: str) -> str:
        m = re.search(r"FR-([A-Z]+)", str(model))
        if not m:
            return "Z"
        s = m.group(1)
        if s.startswith("HEL"): return "HEL"
        if s.startswith("CS"):  return "D"  # group CS with D for pairing
        return s[0]  # D/E/F/A
    out["Series"] = out["Model"].map(series_of)
    return out

def autodetect_csv(year_hint: str):
    # Look in ./data first, then repo root
    candidates = []
    for folder in [Path("data"), Path("."), Path("Datasets"), Path("dataset")]:
        if folder.exists():
            for p in sorted(folder.glob("*.csv")):
                if year_hint in p.name:
                    candidates.append(p)
    return str(candidates[0]) if candidates else None

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--y2024", default=os.environ.get("Y2024_CSV") or autodetect_csv("2024"))
    ap.add_argument("--y2025", default=os.environ.get("Y2025_CSV") or autodetect_csv("2025"))
    ap.add_argument("--outprefix", default=os.environ.get("OUTPREFIX") or DEFAULT_OUTPREFIX)
    args = ap.parse_args()

    if not args.y2024 or not Path(args.y2024).exists():
        print("ERROR: 2024 CSV not found. Provide --y2024 or set Y2024_CSV.", file=sys.stderr)
        sys.exit(1)
    if not args.y2025 or not Path(args.y2025).exists():
        print("ERROR: 2025 CSV not found. Provide --y2025 or set Y2025_CSV.", file=sys.stderr)
        sys.exit(1)

    df24 = read_price_csv(args.y2024)
    df25 = read_price_csv(args.y2025)

    # Anchor order by 2024 appearance per capacity
    df24 = df24.copy()
    df24["_idx"] = range(len(df24))
    df24_sorted = df24.sort_values(["Capacity (kW)", "_idx"])

    # Pair each 2024 item with a 2025 item of same capacity & series (first unused match)
    df25 = df25.copy()
    df25["_used"] = False
    pairs = []
    for _, r24 in df24_sorted.iterrows():
        cap = r24["Capacity (kW)"]
        ser = r24["Series"]
        cand = df25[(df25["Capacity (kW)"] == cap) & (df25["Series"] == ser) & (~df25["_used"])]
        if not cand.empty:
            r25 = cand.iloc[0]
            df25.loc[r25.name, "_used"] = True
        else:
            r25 = None
        pairs.append((r24, r25))

    # Append 2025-only rows within their capacity after the anchored groups
    unused25 = df25[~df25["_used"]].copy().sort_values(["Capacity (kW)", "Series", "Model"])

    cap_order_24 = df24_sorted["Capacity (kW)"].dropna().unique().tolist()
    cap_only_25 = sorted(set(unused25["Capacity (kW)"].dropna().unique()) - set(cap_order_24))
    cap_order_all = sorted(cap_order_24 + cap_only_25)

    group_pairs = []
    for cap in cap_order_all:
        # anchored groups at this capacity (in 2024 sequence)
        group_pairs.extend([(r24, r25) for (r24, r25) in pairs if r24["Capacity (kW)"] == cap])
        # 2025-only at this capacity
        for _, r25 in unused25[unused25["Capacity (kW)"] == cap].iterrows():
            group_pairs.append((None, r25))

    # Emit rows (two per group: 2024 then 2025). 2025 model stays verbatim.
    rows = []
    for r24, r25 in group_pairs:
        # 2024 row
        rows.append({
            "Capacity (kW)": (r24 or r25)["Capacity (kW)"],
            "Year": 2024,
            "Model": (r24["Model"] if r24 is not None else ""),
            "Price (BDT)": (r24["Price (BDT)"] if r24 is not None else ""),
        })
        # 2025 row
        rows.append({
            "Capacity (kW)": (r25 or r24)["Capacity (kW)"],
            "Year": 2025,
            "Model": (r25["Model"] if r25 is not None else ""),
            "Price (BDT)": (r25["Price (BDT)"] if r25 is not None else ""),
        })

    out = pd.DataFrame(rows, columns=["Capacity (kW)", "Year", "Model", "Price (BDT)"])

    # Ensure output folder
    outprefix = Path(args.outprefix)
    outprefix.parent.mkdir(parents=True, exist_ok=True)

    # Save CSV
    csv_path = Path(f"{args.outprefix}.csv")
    out.to_csv(csv_path, index=False, encoding="utf-8-sig")

    # Build Excel with strict two-tone pair banding (white/grey #B3B3B3)
    wb = Workbook()
    ws = wb.active
    ws.title = "First Report"
    headers = ["Capacity (kW)", "Year", "Model", "Price (BDT)"]
    ws.append(headers)

    grey = PatternFill("solid", fgColor="B3B3B3")
    hdr = PatternFill("solid", fgColor="DDDDDD")
    thin = Side(style="thin", color="BBBBBB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    hdr_font = Font(bold=True)
    center = Alignment(horizontal="center", vertical="center")
    left = Alignment(horizontal="left", vertical="center")
    right = Alignment(horizontal="right", vertical="center")

    for c, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = hdr_font
        cell.alignment = center
        cell.fill = hdr
        cell.border = border

    r = 2
    for i in range(0, len(out), 2):
        pair = out.iloc[i:i+2]
        pair_index = i // 2
        fill = grey if (pair_index % 2 == 1) else None
        for _, row in pair.iterrows():
            ws.append([row[h] for h in headers])
            for c, h in enumerate(headers, start=1):
                cell = ws.cell(row=r, column=c)
                cell.border = border
                if h == "Year":
                    cell.alignment = center
                elif h == "Model":
                    cell.alignment = left
                elif h == "Price (BDT)":
                    cell.alignment = right
                else:
                    cell.alignment = center
                if fill:
                    cell.fill = fill
            r += 1

    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 8
    ws.column_dimensions["C"].width = 60
    ws.column_dimensions["D"].width = 18
    ws.freeze_panes = "A2"

    xlsx_path = Path(f"{args.outprefix}.xlsx")
    xlsx_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(xlsx_path)

    print(f"✓ Wrote: {csv_path}")
    print(f"✓ Wrote: {xlsx_path}")

if __name__ == "__main__":
    main()
